@extends('layouts.penuntutan_template')

@section('title', 'Dir.Tut')

@section('stylesheet')

@endsection

@section('maintitle', 'DIREKTORAT PENUNTUTAN')

@section('mainsubtitle', 'Tindak Pidana Khusus')

@section('judulhalaman', 'Ganti Judul Halaman')

@section('materi')

         <p class="text-center"><img src="dist/img/UnderConstruct.png" alt=""></p>
      
@stop

@section('script')

@endsection
