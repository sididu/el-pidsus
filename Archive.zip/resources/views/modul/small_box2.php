<!-- =================BOX-CONTENT======================= -->



<!-- Small boxes (Stat box) -->
<div class="box-body">
  <div class="row">
    <div class="col-md-6 col-xs-12">
      <!-- small box -->
      <?php echo "COLUMN 1"; ?>
    </div>
    <!-- ./col -->
    <div class="col-md-6 col-xs-12">
      <!-- small box -->
     <?php echo "COLUMN 1"; ?>
    </div>
    <!-- ./col -->
  </div>
  <!-- /.row -->
</div>
<!-- ./box-body-->