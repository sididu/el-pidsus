@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <div><h3><a href="home"><img class="push-left" src="dist/img/logo-kejaksaan.png" width="100"></a>
  Dashboard
  <small>Control panel</small>
</h3>
</div>
@stop

@section('content')
<div class="box box-success">
  <div class="box-header with-border">
  <h3 class="box-title text-uppercase">Edit Pasal <small>[Pasal Disangkakan]</small></h3>
    <div class="pull-right">
      <a href="frp1" class="btn btn-defaul btn-xs"> Tambah Kasus &nbsp; <span class="glyphicon glyphicon-plus"></span></a>
    </div>
  </div>
  <div class="box-body">




    <p class="text-center"><img src="dist/img/UnderConstruct.png" alt=""></p>
    






  </div>
  <div class="panel-footer">Panel footer</div>
</div>

@stop