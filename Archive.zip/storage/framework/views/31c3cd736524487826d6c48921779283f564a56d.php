<?php $__env->startSection('title', 'Dir.Dik'); ?>

<?php $__env->startSection('stylesheet'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('maintitle', 'JUDUL UTAMA'); ?>

<?php $__env->startSection('mainsubtitle', 'Sub Title'); ?>

<?php $__env->startSection('judulhalaman', 'Ganti Judul Halaman'); ?>

<?php $__env->startSection('materi'); ?>

        <h1>Hello, OpenLAW.id!</h1>
      
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.penyidikan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>