<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <body>
  <?php echo $__env->make('layouts.penyidikan_mainnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="wrapper">
    <div class="content-wrapper">
      <div class="content-header">
          <?php echo $__env->make('layouts.penyidikanheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
      </div> 

      <div class="content">
       <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title text-uppercase"><?php echo $__env->yieldContent('judulhalaman'); ?></h3>
        </div>
        <div class="box-body">


          <?php echo $__env->yieldContent('materi'); ?>

        </div>
        <div class="panel-footer">Panel footer</div>
      </div><!-- /.box -->
    </div><!-- /.content -->

  </div><!-- /.content-wrapper -->
  <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- /.wrapper -->

    <?php echo $__env->yieldContent('script'); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
  <!-- Latest compiled and minified JavaScript -->
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    </body>
</html>
