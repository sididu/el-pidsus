<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div><h3><a href="home"><img class="push-left" src="dist/img/logo-kejaksaan.png" width="100"></a>
  Dashboard
  <small>Control panel</small>
</h3>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="box box-success">
  <div class="box-header with-border">
  <h3 class="box-title text-uppercase">Edit Data Jaksa <small>[User]</small></h3>
    <div class="pull-right">
      <a href="frp1" class="btn btn-defaul btn-xs"> Tambah Kasus &nbsp; <span class="glyphicon glyphicon-plus"></span></a>
    </div>
  </div>
  <div class="box-body">




    <p class="text-center"><img src="dist/img/UnderConstruct.png" alt=""></p>
    






  </div>
  <div class="panel-footer">Panel footer</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>