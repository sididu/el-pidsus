<?php $__env->startSection('title', 'Dir.Dik'); ?>

<?php $__env->startSection('stylesheet'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('maintitle', 'DIREKTORAT PENYIDIKAN'); ?>

<?php $__env->startSection('mainsubtitle', 'Tindak Pidana Khusus'); ?>

<?php $__env->startSection('judulhalaman', 'Dashboard'); ?>

<?php $__env->startSection('materi'); ?>

<?php echo $__env->make('partials._dataperkara', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-12">
		<?php echo $__env->make('partials._3dpiedonut', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-12">
		<?php echo $__env->make('partials._3dbubble', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>
</div>
<div class="row">
	<div class="col-md-6">
		<?php echo $__env->make('partials._pemulihanaset', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-12">
		<?php echo $__env->make('partials._kerugiannegara', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>
      
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.penyidikan_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>