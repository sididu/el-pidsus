<?php $__env->startSection('title', 'Dir.Dik'); ?>

<?php $__env->startSection('stylesheet'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('maintitle', 'DIREKTORAT PENYIDIKAN'); ?>

<?php $__env->startSection('mainsubtitle', 'Tindak Pidana Khusus'); ?>

<?php $__env->startSection('judulhalaman', 'DAFTAR Tahanan'); ?>

<?php $__env->startSection('materi'); ?>





    <table class="table table-striped">
      <th>
        <td width="33%">
          Tersangka
        </td>
        <td width="33%">
          Kasus
        </td>
        <td width="33%">
          Obyek Pidana
        </td>
      </th>
      <tr>
        <td width="100%" colspan="4">
          <div><?php echo $__env->make('partials._tsk1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        </td>
      </tr>
      <tr>
        <td width="100%" colspan="4">
          <div><?php echo $__env->make('partials._tsk2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        </td>
      </tr>
      <tr>
        <td width="100%" colspan="4">
          <div><?php echo $__env->make('partials._tsk3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        </td>
      </tr>
      <tr>
        <td width="100%" colspan="4">
          <div><?php echo $__env->make('partials._tsk4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        </td>
      </tr>
      <tr>
        <td width="100%" colspan="4">
          <div><?php echo $__env->make('partials._tsk5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        </td>
      </tr>
      <tr>
        <td width="100%" colspan="4">
          <div><?php echo $__env->make('partials._tsk6', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        </td>
      </tr>
      <tr>
        <td width="100%" colspan="4">
          <div><?php echo $__env->make('partials._tsk7', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        </td>
      </tr>
      <tr>
        <td width="100%" colspan="4">
          <div><?php echo $__env->make('partials._tsk8', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        </td>
      </tr>
      <tr>
        <td width="100%" colspan="4">
          <div><?php echo $__env->make('partials._tsk9', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
        </td>
      </tr>

    </table>
    
    





<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.penyidikan_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>