<?php $__env->startSection('title', 'Dir.Dik'); ?>

<?php $__env->startSection('stylesheet'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('maintitle', 'DIREKTORAT PENYIDIKAN'); ?>

<?php $__env->startSection('mainsubtitle', 'Tindak Pidana Khusus'); ?>

<?php $__env->startSection('judulhalaman', 'Ganti Judul Halaman'); ?>

<?php $__env->startSection('materi'); ?>




    <p class="text-center"><img src="dist/img/UnderConstruct.png" alt=""></p>
    






<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.penyidikan_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>