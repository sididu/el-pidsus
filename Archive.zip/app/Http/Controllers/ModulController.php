<?php

namespace App\Http\Controllers;

use App\Tabel_Modul;
use Illuminate\Http\Request;

class ModulController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Tabel_Modul  $tabel_Modul
     * @return \Illuminate\Http\Response
     */
    public function show(Tabel_Modul $tabel_Modul)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Tabel_Modul  $tabel_Modul
     * @return \Illuminate\Http\Response
     */
    public function edit(Tabel_Modul $tabel_Modul)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Tabel_Modul  $tabel_Modul
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tabel_Modul $tabel_Modul)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Tabel_Modul  $tabel_Modul
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tabel_Modul $tabel_Modul)
    {
        //
    }
}
