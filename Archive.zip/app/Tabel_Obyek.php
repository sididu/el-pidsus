<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tabel_Obyek extends Model
{
    //
}
