<h3>
<a href="home"><img class="push-left" src="dist/img/logo-kejaksaan.png" width="100" class="text-titlecase"></a>
         {{--  @yield('maintitle')
          <small> &nbsp; @yield('mainsubtitle')</small> --}}
<div class="pull-right">
            COMING SOON
            <a href="obyek" class="btn btn-app"><i class="fa fa-cubes"></i> RB-1</a>  
            <a href="subyek" class="btn btn-app"><i class="fa fa-odnoklassniki"></i> RT</a>  
</div>
 </h3>