@extends('layouts.penyidikan_template')

@section('title', 'Dir.Dik')

@section('stylesheet')

@endsection

@section('maintitle', 'DIREKTORAT PENYIDIKAN')

@section('mainsubtitle', 'Tindak Pidana Khusus')

@section('judulhalaman', 'Daftar Jaksa Penyidik')

@section('materi')

        <p class="text-center"><img src="dist/img/UnderConstruct.png" alt=""></p>
      
@stop

@section('script')

@endsection
