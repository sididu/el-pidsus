  <!-- Info Boxes Style 2 -->
  <div class="info-box bg-yellow">
    <span class="info-box-icon"><i class="ion ion-ios-pricetag-outline"></i></span>

    <div class="info-box-content">
      <span class="info-box-text">UANG PENGGANTI</span>
      <span class="info-box-number">5,200</span>

      <div class="progress">
        <div class="progress-bar" style="width: 50%"></div>
      </div>
      <span class="progress-description">
        50% Increase in 30 Days
      </span>
    </div>
    <!-- /.info-box-content -->
  </div>
  <!-- /.info-box -->
  <div class="info-box bg-green">
    <span class="info-box-icon"><i class="fa fa-institution"></i></span>

    <div class="info-box-content">
      <span class="info-box-text">Masa Tahanan</span>
      <span class="info-box-number">92,050</span>

      <div class="progress">
        <div class="progress-bar" style="width: 20%"></div>
      </div>
      <span class="progress-description">
        20% Increase in 30 Days
      </span>
    </div>
    <!-- /.info-box-content -->
  </div>
  <!-- /.info-box -->
  <div class="info-box bg-red">
    <span class="info-box-icon"><i class="ion ion-ios-cloud-download-outline"></i></span>

    <div class="info-box-content">
      <span class="info-box-text">Barang Sitaan</span>
      <span class="info-box-number">114,381</span>

      <div class="progress">
        <div class="progress-bar" style="width: 70%"></div>
      </div>
      <span class="progress-description">
        70% Increase in 30 Days
      </span>
    </div>
    <!-- /.info-box-content -->
  </div>
  <!-- /.info-box -->
  <div class="info-box bg-aqua">
    <span class="info-box-icon"><i class="fa  fa-plane"></i></span>

    <div class="info-box-content">
      <span class="info-box-text">Daftar Cekal</span>
      <span class="info-box-number">163,921</span>

      <div class="progress">
        <div class="progress-bar" style="width: 40%"></div>
      </div>
      <span class="progress-description">
        40% Increase in 30 Days
      </span>
    </div>
    <!-- /.info-box-content -->
  </div>
          <!-- /.info-box -->
